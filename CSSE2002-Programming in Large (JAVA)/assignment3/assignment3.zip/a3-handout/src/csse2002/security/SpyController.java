package csse2002.security;

/**
 * The controller for the Spy Simulator.
 */
public class SpyController {

	// the model of the simulator
	private SpyModel model;
	// the view of the simulator
	private SpyView view;

	// REMOVE THIS LINE AND ADD ANY ADDITIONAL VARIABLES YOU REQUIRE HERE

	/**
	 * Initialises the SpyController for the Spy Simulator.
	 */
	public SpyController(SpyModel model, SpyView view) {
		this.model = model;
		this.view = view;
		// REMOVE THIS LINE AND COMPLETE THIS METHOD
	}

	// REMOVE THIS LINE AND ADD YOUR OWN METHODS ETC HERE

}
