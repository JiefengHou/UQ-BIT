package csse2002.security.test;

import junit.framework.Assert;

import org.junit.Test;
import csse2002.math.*;
import csse2002.security.*;
import java.util.*;

public class CompleteSpySimulatorTest {

	/**
	 * The line separator to be used to separate lines in JTextField text.
	 */
	private final String LINE_SEPARATOR = System.getProperty("line.separator");
	/**
	 * The number of times to repeat each test to decrease the chance of it
	 * being right by accident.
	 */
	private final int numTries = 3;

	/**
	 * Test that the Simulator has been properly initialised.
	 */
	@Test(timeout = 10000)
	public void testInitialState() throws Exception {
		BigFraction ks = new BigFraction(1, 2);
		SpyModel model = new SpyModel();
		SpyView view = new SpyView(model);
		new SpyController(model, view);

		// check that cmdRead button is correctly labeled.
		Assert.assertEquals("Read Informants", view.cmdRead.getText());
		// check that cmdMeet button is correctly labeled.
		Assert.assertEquals("Meet Informant", view.cmdMeet.getText());
		// check that cmdGuess button is correctly labeled.
		Assert.assertEquals("Guess Secret", view.cmdGuess.getText());
		// check that txtInformantsFile is correct.
		Assert.assertEquals("", view.txtInformantsFile.getText());
		// check that txtSpy is correct.
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
		// check that txtInfo is correct.
		Assert.assertEquals("", view.txtInfo.getText());
	}

	/**
	 * Test behaviour when file cannot be read because file does not exist, no
	 * informants have yet been loaded.
	 */
	@Test(timeout = 10000)
	public void testFileReadErrorBasic() throws Exception {
		BigFraction ks = new BigFraction(1, 2);
		SpyModel model = new SpyModel();
		SpyView view = new SpyView(model);
		new SpyController(model, view);

		// press Read Informants button when no file is given
		view.cmdRead.doClick();
		this.checkReadErrorState(ks, view);
	}

	/**
	 * Test behaviour when there is no informant to meet because no informants
	 * have been loaded.
	 */
	@Test(timeout = 10000)
	public void testMeetErrorBasic() throws Exception {
		BigFraction ks = new BigFraction(1, 2);
		SpyModel model = new SpyModel();
		SpyView view = new SpyView(model);
		new SpyController(model, view);

		// press meet when no informants have been loaded.
		view.cmdMeet.doClick();
		checkMeetErrorState(ks, view);
	}

	/**
	 * Test basic behaviour when files are read and informants are met.
	 */
	@Test(timeout = 10000)
	public void testFileReadAndMeet() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < numTries; i++) {
			BigFraction ks = new BigFraction(1, 2);
			List<TwoCoinChannel> informants = new ArrayList<TwoCoinChannel>();
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// read in informants (1/3, 1/6), (1/2, 2/3)
			view.txtInformantsFile.setText("informants1.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(1, 3, 1, 6));
			informants.add(getInformant(1, 2, 2, 3));
			this.checkReadState(ks, view);

			// read in more informants (1/2. 1/3)
			view.txtInformantsFile.setText("informants2.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(1, 2, 1, 3));
			this.checkReadState(ks, view);

			// meet all informants read
			while (!informants.isEmpty()) {
				view.cmdMeet.doClick();
				TwoCoinChannel informant = informants.remove(0);
				ks = this.checkMeetState(ks, informant, view);
			}
		}
	}

	/**
	 * Test loading files amidst attempted meets.
	 */
	@Test(timeout = 20000)
	public void testFileReadMeetInterleaved() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < numTries; i++) {
			BigFraction ks = new BigFraction(1, 2);
			List<TwoCoinChannel> informants = new ArrayList<TwoCoinChannel>();
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// read in informants (8/19, 7/13) and (4/5, 5/6) and (1/2, 3/5)
			view.txtInformantsFile.setText("informants3.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(8, 19, 7, 13));
			informants.add(getInformant(4, 5, 5, 6));
			informants.add(getInformant(1, 2, 3, 5));
			this.checkReadState(ks, view);

			// meet informant (8/19, 7/13)
			view.cmdMeet.doClick();
			TwoCoinChannel informant = informants.remove(0);
			ks = this.checkMeetState(ks, informant, view);

			// read in informants (12/23, 6/17), (5/8 1/2)
			view.txtInformantsFile.setText("informants5.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(12, 23, 6, 17));
			informants.add(getInformant(5, 8, 1, 2));
			this.checkReadState(ks, view);

			// meet all informants read
			while (!informants.isEmpty()) {
				view.cmdMeet.doClick();
				informant = informants.remove(0);
				ks = this.checkMeetState(ks, informant, view);
			}

			// meet informant, but list has now been emptied
			view.cmdMeet.doClick();
			this.checkMeetErrorState(ks, view);

			// read in one more informant (1/2. 1/3) to an empty list
			view.txtInformantsFile.setText("informants2.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(1, 2, 1, 3));
			this.checkReadState(ks, view);

			// meet informant (1/2, 1/3)
			view.cmdMeet.doClick();
			informant = informants.remove(0);
			ks = this.checkMeetState(ks, informant, view);

			// meet informant, but list has now been emptied again
			view.cmdMeet.doClick();
			this.checkMeetErrorState(ks, view);
		}
	}

	/**
	 * Test loading an empty file of informants amidst other reads.
	 */
	@Test(timeout = 20000)
	public void testFileReadEmptyFileAmidstValidReads() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < numTries; i++) {
			BigFraction ks = new BigFraction(1, 2);
			List<TwoCoinChannel> informants = new ArrayList<TwoCoinChannel>();
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// read in informants (8/19, 7/13) and (4/5, 5/6) and (1/2, 3/5)
			view.txtInformantsFile.setText("informants3.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(8, 19, 7, 13));
			informants.add(getInformant(4, 5, 5, 6));
			informants.add(getInformant(1, 2, 3, 5));
			this.checkReadState(ks, view);

			// meet informant (8/19, 7/13)
			view.cmdMeet.doClick();
			TwoCoinChannel informant = informants.remove(0);
			ks = this.checkMeetState(ks, informant, view);

			// load in empty list of informants
			view.txtInformantsFile.setText("informants4.txt");
			view.cmdRead.doClick();
			this.checkReadState(ks, view);

			// meet all informants read
			while (!informants.isEmpty()) {
				view.cmdMeet.doClick();
				informant = informants.remove(0);
				ks = this.checkMeetState(ks, informant, view);
			}

			// meet informant, but list has now been emptied
			view.cmdMeet.doClick();
			checkMeetErrorState(ks, view);
		}
	}

	/**
	 * Test read error amidst other reads.
	 */
	@Test(timeout = 10000)
	public void testFileReadErrorAmidstValidReads() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < numTries; i++) {
			BigFraction ks = new BigFraction(1, 2);
			List<TwoCoinChannel> informants = new ArrayList<TwoCoinChannel>();
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// read in informants (8/19, 7/13) and (4/5, 5/6) and (1/2, 3/5)
			view.txtInformantsFile.setText("informants3.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(8, 19, 7, 13));
			informants.add(getInformant(4, 5, 5, 6));
			informants.add(getInformant(1, 2, 3, 5));
			this.checkReadState(ks, view);

			// meet informant (8/19, 7/13)
			view.cmdMeet.doClick();
			TwoCoinChannel informant = informants.remove(0);
			ks = this.checkMeetState(ks, informant, view);

			// load in a list of informants that cannot be read
			view.txtInformantsFile.setText("fileDoesNotExist.txt");
			view.cmdRead.doClick();
			this.checkReadErrorState(ks, view);

			// read in more informants (12/23, 6/17), (5/8 1/2)
			view.txtInformantsFile.setText("informants5.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(12, 23, 6, 17));
			informants.add(getInformant(5, 8, 1, 2));
			this.checkReadState(ks, view);

			// meet all informants read
			while (!informants.isEmpty()) {
				view.cmdMeet.doClick();
				informant = informants.remove(0);
				ks = this.checkMeetState(ks, informant, view);
			}

			// meet informant, but list has now been emptied
			view.cmdMeet.doClick();
			checkMeetErrorState(ks, view);
		}
	}

	/**
	 * Test spy guessing from initial state of simulation.
	 */
	@Test(timeout = 10000)
	public void testGuessBasic() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < numTries; i++) {
			BigFraction ks = new BigFraction(1, 2);
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// make a guess
			view.cmdGuess.doClick();
			ks = this.checkGuessState(ks, view);
		}
	}

	/**
	 * Test spy guessing after an informant has been met.
	 */
	@Test(timeout = 10000)
	public void testGuess() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < numTries; i++) {
			BigFraction ks = new BigFraction(1, 2);
			List<TwoCoinChannel> informants = new ArrayList<TwoCoinChannel>();
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// read in informants (1/3, 1/6), (1/2, 2/3)
			view.txtInformantsFile.setText("informants1.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(1, 3, 1, 6));
			informants.add(getInformant(1, 2, 2, 3));
			this.checkReadState(ks, view);

			// meet an informant
			view.cmdMeet.doClick();
			TwoCoinChannel informant = informants.remove(0);
			ks = this.checkMeetState(ks, informant, view);

			// make a guess
			view.cmdGuess.doClick();
			ks = this.checkGuessState(ks, view);
		}
	}

	/**
	 * Test spy guessing when informant knows secret with probability one.
	 */
	@Test(timeout = 20000)
	public void testCertainGuesses() throws Exception {
		// repeat test to decrease the chance of getting it right by accident
		for (int i = 0; i < 10; i++) {
			BigFraction ks = new BigFraction(1, 2);
			List<TwoCoinChannel> informants = new ArrayList<TwoCoinChannel>();
			SpyModel model = new SpyModel();
			SpyView view = new SpyView(model);
			new SpyController(model, view);

			// read in tell-all informant (0, 1) and another informant
			view.txtInformantsFile.setText("informants6.txt");
			view.cmdRead.doClick();
			informants.add(getInformant(0, 1, 1, 1));
			informants.add(getInformant(1, 2, 1, 3));
			this.checkReadState(ks, view);

			// meet tell-all informant and other informant
			while (!informants.isEmpty()) {
				view.cmdMeet.doClick();
				TwoCoinChannel informant = informants.remove(0);
				ks = this.checkMeetState(ks, informant, view);
			}
			// make a guess
			view.cmdGuess.doClick();
			this.checkCertainGuessState(ks, view);
		}
	}

	// HELPER METHODS

	/**
	 * Check state after a valid read.
	 */
	private void checkReadState(BigFraction ks, SpyView view) {
		// check that txtSpy is correct.
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
		// check that txtInfo is correct.
		Assert.assertEquals(getReadMessage(), view.txtInfo.getText());
	}

	/**
	 * Check state after an invalid read.
	 */
	private void checkReadErrorState(BigFraction ks, SpyView view) {
		// check that txtSpy is correct.
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
		// check that txtInfo is correct.
		Assert.assertEquals(getReadError(), view.txtInfo.getText());
	}

	/**
	 * Checks the state is correct after a meet, and returns new knowledge state
	 * of spy after meet.
	 */
	private BigFraction checkMeetState(BigFraction ks,
			TwoCoinChannel informant, SpyView view) throws Exception {
		String actualTxtInfo = view.txtInfo.getText();
		Boolean outcome;
		if (actualTxtInfo.equals(getInfoString(informant, true))) {
			outcome = true;
		} else {
			Assert.assertEquals(getInfoString(informant, false), actualTxtInfo);
			outcome = false;
		}
		ks = informant.aPosteriori(ks, outcome);
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
		return ks;
	}

	/**
	 * Check meet state when there are no more informants to meet.
	 */
	private void checkMeetErrorState(BigFraction ks, SpyView view) {
		// check that txtSpy is correct.
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
		// check that txtInfo is correct.
		Assert.assertEquals(getMeetError(), view.txtInfo.getText());
	}

	/**
	 * Checks the state is correct after a guess, and returns new knowledge
	 * state of spy after meet.
	 */
	private BigFraction checkGuessState(BigFraction ks, SpyView view)
			throws Exception {
		String actualTxtInfo = view.txtInfo.getText();
		Boolean secret;
		Boolean guess =
				((ks.compareTo(new BigFraction(1, 2)) >= 0) ? true : false);
		if (actualTxtInfo.equals(getInfoString(true, guess))) {
			secret = true;
		} else {
			Assert.assertEquals(getInfoString(false, guess), actualTxtInfo);
			secret = false;
		}
		ks = (secret ? BigFraction.ONE : BigFraction.ZERO);
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
		return ks;
	}

	/**
	 * Checks the state is correct after a certain guess, and returns new
	 * knowledge state of spy after meet. ks must be zero or one.
	 */
	private void checkCertainGuessState(BigFraction ks, SpyView view)
			throws Exception {

		Boolean guess = (ks.equals(BigFraction.ONE) ? true : false);
		Boolean secret = guess; // it has to be

		Assert.assertEquals(getInfoString(secret, guess),
				view.txtInfo.getText());
		Assert.assertEquals(getSpyString(ks), view.txtSpy.getText());
	}

	private void checkButtons(SpyView view) throws Exception {
		// check that cmdRead button is correctly labeled.
		Assert.assertEquals("Read Informants", view.cmdRead.getText());
		// check that cmdMeet button is correctly labeled.
		Assert.assertEquals("Meet Informant", view.cmdMeet.getText());
		// check that cmdGuess button is correctly labeled.
		Assert.assertEquals("Guess Secret", view.cmdGuess.getText());
	}

	/**
	 * Shorthand for instantiating a TwoCoinChannel with coin1 = n1/d1 and
	 * coin2=n2/d2.
	 */
	private TwoCoinChannel getInformant(int n1, int d1, int n2, int d2) {
		return new TwoCoinChannel(new BigFraction(n1, d1), new BigFraction(n2,
				d2));
	}

	// HELPER METHODS FOR OUTPUT STRINGS

	private String getSpyString(BigFraction p) {
		return "Spy thinks ..." + LINE_SEPARATOR
				+ "Secret is true with probability " + p;
	}

	private String getReadError() {
		return "Error reading from file.";
	}

	private String getReadMessage() {
		return "Informants added from file.";
	}

	private String getMeetError() {
		return "There is no informant to meet.";
	}

	private String getInfoString(TwoCoinChannel informant, boolean outcome) {
		return "Informant says ..." + LINE_SEPARATOR + "Heads-bias if true: "
				+ informant.getCoinBias(true) + LINE_SEPARATOR
				+ "Heads-bias if false: " + informant.getCoinBias(false)
				+ LINE_SEPARATOR + "Result is ... "
				+ (outcome ? "heads" : "tails") + "!";
	}

	private String getInfoString(Boolean secret, Boolean guess) {
		return "Spy guesses that secret is " + guess + LINE_SEPARATOR
				+ "and is ... " + (secret == guess ? "correct" : "incorrect")
				+ "!";
	}
}
