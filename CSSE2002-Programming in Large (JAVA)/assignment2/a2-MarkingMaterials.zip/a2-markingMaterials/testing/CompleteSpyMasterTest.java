package csse2002.security.test;

import org.junit.Assert;
import org.junit.Test;

import csse2002.math.*;
import csse2002.security.*;

import java.util.*;
import java.io.*;

/**
 * Basic tests for the {@link SpyMaster} implementation class. A much more
 * extensive test suite will be performed for assessment of your code, but this
 * should get you started.
 */
public class CompleteSpyMasterTest {

	// TESTS for readInformants

	// Tests for valid files

	/**
	 * Test reading from a well formatted file with zero lines
	 */
	@Test(timeout=5000)
	public void testReadInformantsEmptyFile() throws FileFormatException,
			IOException {
		List<ConditionalTwoCoinChannel> expectedInformants =
				new ArrayList<ConditionalTwoCoinChannel>();

		List<ConditionalTwoCoinChannel> actualInformants =
				SpyMaster.readInformants("cinput1.txt");
		Assert.assertEquals(expectedInformants, actualInformants);
	}

	/**
	 * Test reading from a well formatted file with one line
	 */
	@Test(timeout=5000)
	public void testReadInformantsOneLine() throws FileFormatException,
			IOException {
		List<ConditionalTwoCoinChannel> expectedInformants =
				new ArrayList<ConditionalTwoCoinChannel>();
		addInformant(expectedInformants, 6, 11, 5, 7, 1, 5);

		List<ConditionalTwoCoinChannel> actualInformants =
				SpyMaster.readInformants("cinput2.txt");
		Assert.assertEquals(expectedInformants, actualInformants);
	}

	/**
	 * Test reading from a well typical formatted file with many lines
	 */
	@Test(timeout=5000)
	public void testReadInformantsManyLinesTypical()
			throws FileFormatException, IOException {
		List<ConditionalTwoCoinChannel> expectedInformants =
				new ArrayList<ConditionalTwoCoinChannel>();

		addInformant(expectedInformants, 5, 8, 4, 11, 2, 10);
		addInformant(expectedInformants, 6, 7, 1, 3, 21, 310);
		addInformant(expectedInformants, 211, 337, 4, 91, 3, 4);

		List<ConditionalTwoCoinChannel> actualInformants =
				SpyMaster.readInformants("cinput3.txt");
		Assert.assertEquals(expectedInformants, actualInformants);
	}

	/**
	 * Test reading from a well formatted file with many lines, 0 and 1 valid
	 * probabilities
	 */
	@Test(timeout=5000)
	public void testReadInformantsManyLinesZeroOneProbs()
			throws FileFormatException, IOException {
		List<ConditionalTwoCoinChannel> expectedInformants =
				new ArrayList<ConditionalTwoCoinChannel>();
		addInformant(expectedInformants, 0, 1, 3, 4, 1, 2);
		addInformant(expectedInformants, 6, 7, 0, 1, 2, 3);
		addInformant(expectedInformants, 2, 7, 4, 9, 0, 1);
		addInformant(expectedInformants, 1, 1, 3, 4, 1, 2);
		addInformant(expectedInformants, 6, 7, 1, 1, 2, 3);
		addInformant(expectedInformants, 2, 7, 4, 9, 1, 1);
		addInformant(expectedInformants, 0, 1, 1, 1, 0, 1);

		List<ConditionalTwoCoinChannel> actualInformants =
				SpyMaster.readInformants("cinput4.txt");
		Assert.assertEquals(expectedInformants, actualInformants);
	}

	/**
	 * Test reading from a well formatted file with many lines, different valid
	 * spacings
	 */
	@Test(timeout=5000)
	public void testReadInformantsManyLinesSpacing()
			throws FileFormatException, IOException {
		List<ConditionalTwoCoinChannel> expectedInformants =
				new ArrayList<ConditionalTwoCoinChannel>();

		addInformant(expectedInformants, 5, 8, 4, 11, 2, 10);
		addInformant(expectedInformants, 6, 7, 1, 3, 21, 310);
		addInformant(expectedInformants, 211, 337, 4, 91, 3, 4);

		List<ConditionalTwoCoinChannel> actualInformants =
				SpyMaster.readInformants("cinput5.txt");
		Assert.assertEquals(expectedInformants, actualInformants);
	}

	// TESTS for IOExceptions

	/**
	 * Test reading from a file that does not exist.
	 */
	@Test(timeout=5000, expected = IOException.class)
	public void testReadInformantsIOError() throws FileFormatException,
			IOException {
		List<ConditionalTwoCoinChannel> actualInformants =
				SpyMaster.readInformants("doesNotExist.txt");
	}

	// TESTS for poorly formatted files

	/**
	 * Test reading from poorly-formatted files of informants: invalid
	 * probabilities
	 */
	@Test(timeout=5000)
	public void testReadInformantsFormatProbabilityErrors()
			throws FileFormatException, IOException {
		boolean caught = false;
		// test first probability is invalid
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput6.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test second probability is invalid
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput7.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test third probability is invalid
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput8.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test negative probability
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput9.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
	}

	/**
	 * Test reading from poorly-formatted files of informants: missing
	 * probabilities on lines
	 */
	@Test(timeout=5000)
	public void testReadInformantsFormatMissingProbabilityErrors()
			throws FileFormatException, IOException {
		boolean caught = false;
		// test missing one probability on one line
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput10.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test missing two probabilities on one line
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput11.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test missing three probabilities on one line: first and last
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput12.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test missing three probabilities on one line: middle
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput13.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
	}

	/**
	 * Test reading from poorly-formatted files of informants: extra text
	 */
	@Test(timeout=5000)
	public void testReadInformantsFormatExtraText() throws FileFormatException,
			IOException {
		boolean caught = false;
		// test extra text at start of file
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput14.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test extra text at middle of file
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput15.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
		// test extra text at end of file
		try {
			List<ConditionalTwoCoinChannel> actualInformants =
					SpyMaster.readInformants("cinput16.txt");
		} catch (FileFormatException e) {
			caught = true;
		}
		Assert.assertTrue(caught);
		caught = false;
	}

	// TESTS for findInformants

	/**
	 * Test finding informants in special case that no new informants are
	 * needed, and the spies have point distributions.
	 */
	@Test(timeout=5000)
	public void testInformantsNotRequiredSpecialCase() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 3);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();
		// add informants so that spy0 = {{true@1/3, false@2/3}@1}
		// add informants so that spy1 = {{true@1/3, false@2/3}@1}

		SpyMaster.findAdditionalInformants(aPriori, informants);
		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy = "{{true@1/3, false@2/3}@1}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in special case that no new informants are
	 * needed, but the spies have distributions with support > 1.
	 */
	@Test(timeout=5000)
	public void testInformantsNotRequired() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 =
		// {{{true@1/3, false@2/3}@1/4,
		// {true@1/2, false@1/2}@1/6,
		// {true@4/7, false@3/7}@7/12}
		informants.get(0).add(
				new ConditionalTwoCoinChannel(aPriori, new TwoCoinChannel(
						new BigFraction(1, 6), new BigFraction(1, 3))));
		informants.get(0).add(
				new ConditionalTwoCoinChannel(new BigFraction(5, 9),
						new TwoCoinChannel(new BigFraction(1, 5),
								new BigFraction(1, 4))));
		// add informants so that
		// kd1 =
		// {{{true@1/3, false@2/3}@1/4,
		// {true@1/2, false@1/2}@1/6,
		// {true@4/7, false@3/7}@7/12}
		informants.get(1).add(
				new ConditionalTwoCoinChannel(aPriori, new TwoCoinChannel(
						new BigFraction(1, 3), new BigFraction(1, 2))));
		informants.get(1).add(
				new ConditionalTwoCoinChannel(new BigFraction(2, 5),
						new TwoCoinChannel(new BigFraction(1, 2),
								new BigFraction(2, 3))));

		SpyMaster.findAdditionalInformants(aPriori, informants);
		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@1/3, false@2/3}@1/4, {true@1/2, false@1/2}@1/6,"
						+ " {true@4/7, false@3/7}@7/12}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in special case that new informants are only
	 * required for the first spy: only one more informant needed.
	 */
	@Test(timeout=5000)
	public void testInformantsRequiredFirstSpyOnly() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 =
		// {{true@1/3, false@2/3}@1/4,
		// {true@5/9, false@4/9}@3/4}
		this.addInformant(informants.get(0), 1, 2, 1, 6, 1, 3);

		// add informants so that
		// kd1 =
		// {{true@1/3, false@2/3}@1/4,
		// {true@1/2, false@1/2}@1/6,
		// {true@4/7, false@3/7}@7/12}

		this.addInformant(informants.get(1), 1, 2, 1, 3, 1, 2);
		this.addInformant(informants.get(1), 2, 5, 1, 2, 2, 3);

		// System.out.println(new KnowledgeDistribution(aPriori,
		// informants.get(0)));
		// System.out.println(new KnowledgeDistribution(aPriori,
		// informants.get(1)));

		SpyMaster.findAdditionalInformants(aPriori, informants);
		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@1/3, false@2/3}@1/4, {true@1/2, false@1/2}@1/6, "
						+ "{true@4/7, false@3/7}@7/12}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
		// System.out.println(informants.get(0));
		// System.out.println(informants.get(1));
	}

	/**
	 * Test finding informants in special case that new informants are only
	 * required for the second spy: only one more informant needed.
	 */
	@Test(timeout=5000)
	public void testInformantsRequiredSecondSpyOnly() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 =
		// {{{true@1/3, false@2/3}@1/4,
		// {true@1/2, false@1/2}@1/6,
		// {true@4/7, false@3/7}@7/12}
		informants.get(0).add(
				new ConditionalTwoCoinChannel(aPriori, new TwoCoinChannel(
						new BigFraction(1, 6), new BigFraction(1, 3))));
		informants.get(0).add(
				new ConditionalTwoCoinChannel(new BigFraction(5, 9),
						new TwoCoinChannel(new BigFraction(1, 5),
								new BigFraction(1, 4))));
		// add informants so that
		// kd1 = {{true@2/5, false@3/5}@5/12, {true@4/7, false@3/7}@7/12}
		informants.get(1).add(
				new ConditionalTwoCoinChannel(aPriori, new TwoCoinChannel(
						new BigFraction(1, 3), new BigFraction(1, 2))));

		SpyMaster.findAdditionalInformants(aPriori, informants);
		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@1/3, false@2/3}@1/4, {true@1/2, false@1/2}@1/6, "
						+ "{true@4/7, false@3/7}@7/12}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in special case that new informants are only
	 * required for the first spy: many informants needed
	 */
	@Test(timeout=5000)
	public void testInformantsRequiredManyFirstSpyOnly() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 = {{true@1/3, false@2/3}@1/4,
		// {true@49/89, false@40/89}@89/240,
		// {true@51/91, false@40/91}@91/240}
		//
		this.addInformant(informants.get(0), 1, 2, 1, 6, 2, 6);
		this.addInformant(informants.get(0), 5, 9, 49, 100, 1, 2);

		// add informants so that
		// kd1 = {{true@1/4, false@3/4}@1/3, {true@5/8, false@3/8}@2/3}
		//
		this.addInformant(informants.get(1), 1, 2, 5, 6, 1, 2);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));

		SpyMaster.findAdditionalInformants(aPriori, informants);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));
		//System.out.println(informants.get(0));
		//System.out.println(informants.get(1));

		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@1/4, false@3/4}@1/3, {true@5/8, false@3/8}@2/3}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in special case that new informants are only
	 * required for the second spy: many informants needed
	 */
	@Test(timeout=5000)
	public void testInformantsRequiredManySecondSpyOnly() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 = {{true@1/4, false@3/4}@1/3, {true@5/8, false@3/8}@2/3}
		//
		this.addInformant(informants.get(0), 1, 2, 5, 6, 1, 2);

		// add informants so that
		// kd1 = {{true@1/3, false@2/3}@1/4, {true@5/9, false@4/9}@3/4}
		//
		this.addInformant(informants.get(1), 1, 2, 1, 6, 2, 6);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));

		SpyMaster.findAdditionalInformants(aPriori, informants);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));
		//System.out.println(informants.get(0));
		//System.out.println(informants.get(1));

		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@1/4, false@3/4}@1/3, {true@5/8, false@3/8}@2/3}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in typical case that new informants are required
	 * for both spies: only one extra informant needed for each
	 */
	@Test(timeout=5000)
	public void testInformantsRequiredBothSpies() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 =
		// {{true@0, false@1}@1/12,
		// {true@1/2, false@1/2}@1/6,
		// {true@5/9,false@4/9}@3/4}
		informants.get(0).add(
				new ConditionalTwoCoinChannel(aPriori, new TwoCoinChannel(
						BigFraction.ZERO, new BigFraction(1, 6))));
		informants.get(0).add(
				new ConditionalTwoCoinChannel(new BigFraction(6, 11),
						new TwoCoinChannel(new BigFraction(1, 6),
								new BigFraction(1, 5))));

		// add informants so that
		// kd1 =
		// {{true@1/3, false@2/3}@1/4,
		// {true@1/2,false@1/2}@1/6,
		// {true@4/7, false@3/7}@7/12}
		informants.get(1).add(
				new ConditionalTwoCoinChannel(aPriori, new TwoCoinChannel(
						new BigFraction(1, 6), new BigFraction(1, 3))));
		informants.get(1).add(
				new ConditionalTwoCoinChannel(new BigFraction(5, 9),
						new TwoCoinChannel(new BigFraction(1, 5),
								new BigFraction(1, 4))));

		SpyMaster.findAdditionalInformants(aPriori, informants);
		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));

		// check that final distribution of both spies is as expected
		String expectedSpy =
				"{{true@0, false@1}@1/12, {true@1/2, false@1/2}@1/3,"
						+ " {true@4/7, false@3/7}@7/12}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in typical case that new informants are required
	 * for both spies: many extra informants needed for each
	 */
	@Test(timeout=5000)
	public void testInformantsManyRequiredBothSpies() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(1, 2);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 = {{true@1/3, false@2/3}@1/4, {true@5/14, false@9/14}@7/54, {true@10/19, false@9/19}@19/108, {true@5/8, false@3/8}@4/9}
		//
		this.addInformant(informants.get(0), 1, 2, 1, 6, 2, 6);
		this.addInformant(informants.get(0), 5, 9, 1, 3, 1, 3);
		this.addInformant(informants.get(0), 5, 9, 1, 3, 1, 2);
		this.addInformant(informants.get(0), 5, 11, 1, 3, 1, 2);

		// add informants so that
		// kd1 = {{true@8/23, false@15/23}@23/48, {true@8/13, false@5/13}@13/48, {true@2/3, false@1/3}@1/4}
		//
		this.addInformant(informants.get(1), 1, 2, 2, 6, 1, 6);
		this.addInformant(informants.get(1), 4, 9, 1, 2, 1, 4);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));

		SpyMaster.findAdditionalInformants(aPriori, informants);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));
		//System.out.println(informants.get(0));
		//System.out.println(informants.get(1));

		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@1/3, false@2/3}@1/4, {true@5/14, false@9/14}@7/54, {true@16/43, false@27/43}@43/432, {true@8/13, false@5/13}@13/48, {true@2/3, false@1/3}@1/4}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}

	/**
	 * Test finding informants in typical case that new informants are required
	 * for both spies: many extra informants needed for each: secret not fair
	 */
	@Test(timeout=5000)
	public void testInformantsManyRequiredBothSpiesUnfairInitialSecret() {
		// initial secret probability
		BigFraction aPriori = new BigFraction(2, 3);
		// create empty lists of informants
		List<List<ConditionalTwoCoinChannel>> informants =
				getEmptyInformantsList();

		// add informants so that
		// kd0 = {{true@2/5, false@3/5}@5/18, {true@8/11, false@3/11}@55/108, {true@20/23, false@3/23}@23/108}
		//
		this.addInformant(informants.get(0), 2, 3, 1, 6, 1, 2);
		this.addInformant(informants.get(0), 10, 13, 1, 3, 1, 6);
		

		// this.addInformant(informants.get(0), 5, 9, 2, 6, 1, 6);

		// add informants so that
		// kd1 = {{true@24/149, false@125/149}@149/810, {true@16/21, false@5/21}@7/36, {true@432/557, false@125/557}@557/1620, {true@4/5, false@1/5}@5/18}
		//
		this.addInformant(informants.get(1), 2, 3, 2, 6, 1, 6);
		this.addInformant(informants.get(1), 8, 13, 2, 6, 1, 6);
		this.addInformant(informants.get(1), 32, 57, 9, 10, 1, 3);
		

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));

		SpyMaster.findAdditionalInformants(aPriori, informants);

		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(0)));
		//System.out.println(new KnowledgeDistribution(aPriori, informants.get(1)));
		//System.out.println(informants.get(0));
		//System.out.println(informants.get(1));

		// Calculate the actual distribution of both spies after all initial and
		// additional informants have visited.
		KnowledgeDistribution actualSpy0 =
				new KnowledgeDistribution(aPriori, informants.get(0));
		KnowledgeDistribution actualSpy1 =
				new KnowledgeDistribution(aPriori, informants.get(1));
		String expectedSpy =
				"{{true@24/149, false@125/149}@149/810, {true@732/977, false@245/977}@977/1620, {true@20/23, false@3/23}@23/108}";
		Assert.assertEquals(expectedSpy, actualSpy0.toString());
		Assert.assertEquals(expectedSpy, actualSpy1.toString());
	}
	
	// HELPER METHODS

	/**
	 * @return An empty list of two lists of informants.
	 */
	public List<List<ConditionalTwoCoinChannel>> getEmptyInformantsList() {
		List<List<ConditionalTwoCoinChannel>> informants =
				new ArrayList<List<ConditionalTwoCoinChannel>>();
		informants.add(new ArrayList<ConditionalTwoCoinChannel>());
		informants.add(new ArrayList<ConditionalTwoCoinChannel>());
		return informants;
	}

	/**
	 * @return Add a new informant to informants
	 */
	public void addInformant(List<ConditionalTwoCoinChannel> informants, int a,
			int b, int c, int d, int e, int f) {
		informants
				.add(new ConditionalTwoCoinChannel(new BigFraction(a, b),
						new TwoCoinChannel(new BigFraction(c, d),
								new BigFraction(e, f))));
	}

}
